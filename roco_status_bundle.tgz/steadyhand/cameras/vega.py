"""Vega U camera acquisition.

This module is deliberately independent of Robot(): constructing dexcontrol
Robot() moves the head. Camera acquisition therefore uses the sensor-only head
API and the local wrist-camera API.

Head:
- ZED X Mini stereo on the head
- rectified left/right RGB + depth in metres
- configured 1920x1200 @ 30 fps; competition guidance reports ~24 Hz observed
- no native point-cloud stream; point clouds are reconstructed from depth + K

Wrists:
- two Sony ISX031 cameras
- local WristCameras API returns wrist_a / wrist_b
- VERIFIED_ON_COMP_ROBOT 2026-09-28: wrist_a=RIGHT, wrist_b=LEFT
- wrist timestamps are not synchronized to head timestamps
"""

from dataclasses import dataclass
import math
import json
import os
from pathlib import Path
import selectors
import subprocess
import tempfile
import time
from typing import Any, Mapping


@dataclass(frozen=True)
class HeadCameraFrame:
    left_rgb: Any
    right_rgb: Any
    depth_m: Any
    left_timestamp_ns: int | None
    right_timestamp_ns: int | None
    depth_timestamp_ns: int | None
    camera_info: Any


@dataclass(frozen=True)
class WristCameraFrame:
    rgb: Any
    frame_id: int | None
    timestamp_ns: int | None
    received_monotonic_ns: int | None


@dataclass(frozen=True)
class WristPair:
    wrist_a: WristCameraFrame
    wrist_b: WristCameraFrame


def _restart_head_camera_service(robot_name: str) -> None:
    """Restart the Jetson head-camera publisher once after startup failure."""
    subprocess.run(
        ["pkill", "-f", "dexsensor.*head_camera"],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    log_path = Path(os.path.expanduser("~/head_camera.log"))
    environment = os.environ.copy()
    environment["ROBOT_NAME"] = robot_name
    environment.pop("PYTHONPATH", None)
    with log_path.open("ab") as log:
        subprocess.Popen(
            [
                "dexsensor", "-v", "info", "launch",
                "--config", "/etc/dexmate/dexsensor/default.toml",
                "--robot", robot_name,
                "--sensor", "head_camera",
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
            env=environment,
        )
    wait_s = float(os.environ.get("VEGA_HEAD_CAMERA_RESTART_WAIT_S", "4.0"))
    if not math.isfinite(wait_s) or wait_s <= 0:
        wait_s = 4.0
    time.sleep(wait_s)


class VegaHeadCamera:
    """Sensor-only ZED subscriber. Does not construct dexcontrol Robot()."""

    def __init__(self) -> None:
        self._sensors = None
        self._head = None
        # Keep the resolved name from connect().  On some onsite shells
        # ROBOT_NAME is not exported, while dexcontrol still provides it in
        # its loaded config.  Read recovery must use the same name.
        self._robot_name = None

    def connect(self) -> None:
        if self._sensors is not None:
            return
        from dexcontrol.core.config import get_robot_config
        from dexcontrol.sensors.manager import Sensors

        configs = get_robot_config()
        if "head_camera" not in configs.sensors:
            raise RuntimeError("dexcontrol config has no head_camera")
        configs.sensors["head_camera"].enabled = True
        robot_name = os.environ.get("ROBOT_NAME") or getattr(configs, "robot_name", None)
        self._robot_name = None if robot_name is None else str(robot_name)
        last_error = None
        for attempt in range(2):
            sensors = None
            try:
                sensors = Sensors({"head_camera": configs.sensors["head_camera"]})
                sensors.wait_for_all_active(timeout=10)
            except Exception as exc:
                last_error = exc
                if sensors is not None:
                    try:
                        sensors.shutdown()
                    except Exception:
                        pass
                if attempt == 0 and robot_name:
                    print(
                        "HEAD CAMERA START FAILED; restarting dexsensor and retrying once",
                        flush=True,
                    )
                    try:
                        _restart_head_camera_service(str(robot_name))
                    except Exception as recovery_exc:
                        raise RuntimeError(
                            f"head camera recovery could not relaunch dexsensor: {recovery_exc}"
                        ) from exc
                    continue
                raise
            self._sensors = sensors
            self._head = sensors.head_camera
            return
        raise RuntimeError("head camera failed to start after recovery retry") from last_error

    def close(self) -> None:
        if self._sensors is not None:
            self._sensors.shutdown()
        self._sensors = None
        self._head = None

    def camera_info(self):
        self._require_connected()
        return self._head.get_camera_info()

    def read(
        self,
        *,
        include_depth: bool = True,
        timeout_s: float = 15.0,
        poll_s: float = 0.05,
    ) -> HeadCameraFrame:
        """Wait for the requested ZED streams and usable camera info.

        The competition ZED can report initialized before its first Zenoh
        frames are available, especially immediately after Robot() has moved
        the head. A single-shot read therefore creates a false failure during
        normal startup. Keep acquisition bounded, but tolerate that warm-up.
        """
        self._require_connected()
        timeout_s = float(timeout_s)
        poll_s = float(poll_s)
        if not math.isfinite(timeout_s) or timeout_s <= 0:
            raise ValueError("timeout_s must be finite and > 0")
        if not math.isfinite(poll_s) or poll_s < 0:
            raise ValueError("poll_s must be finite and >= 0")

        keys = ["left_rgb", "right_rgb"]
        if include_depth:
            keys.append("depth")

        deadline = time.monotonic() + timeout_s
        recovery_attempted = False
        robot_name = self._robot_name or os.environ.get("ROBOT_NAME")
        last_missing = list(keys)
        last_info_error = None
        while True:
            obs = self._head.get_obs(obs_keys=keys, include_timestamp=True)
            last_missing = [key for key in keys if obs.get(key) is None]
            if not last_missing:
                try:
                    camera_info = self._head.get_camera_info()
                except Exception as exc:
                    # The info service has also been observed to come up late.
                    # Retry it within the same bounded warm-up window.
                    last_info_error = exc
                else:
                    depth = obs.get("depth")
                    return HeadCameraFrame(
                        left_rgb=obs["left_rgb"]["data"],
                        right_rgb=obs["right_rgb"]["data"],
                        depth_m=None if depth is None else depth["data"],
                        left_timestamp_ns=obs["left_rgb"].get("timestamp_ns"),
                        right_timestamp_ns=obs["right_rgb"].get("timestamp_ns"),
                        depth_timestamp_ns=None if depth is None else depth.get("timestamp_ns"),
                        camera_info=camera_info,
                    )

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                # ``Sensors.wait_for_all_active`` can report success while
                # the publisher's camera-info service is still absent after
                # reboot.  Restart the proven dexsensor publisher once and
                # give the complete read window another bounded attempt.
                if not recovery_attempted and robot_name:
                    recovery_attempted = True
                    print(
                        "HEAD CAMERA READ FAILED; restarting dexsensor and retrying once",
                        flush=True,
                    )
                    try:
                        self.close()
                        _restart_head_camera_service(str(robot_name))
                        self.connect()
                    except Exception as recovery_exc:
                        raise RuntimeError(
                            f"head camera recovery could not relaunch dexsensor: {recovery_exc}"
                        ) from (last_info_error or RuntimeError("head camera read timed out"))
                    deadline = time.monotonic() + timeout_s
                    last_missing = list(keys)
                    last_info_error = None
                    continue
                if last_info_error is not None and not last_missing:
                    raise RuntimeError(
                        "Vega head streams are ready but camera info is unavailable "
                        f"after {timeout_s:.1f}s"
                    ) from last_info_error
                raise RuntimeError(
                    "Vega head streams are not ready after "
                    f"{timeout_s:.1f}s; missing: {', '.join(last_missing)}"
                )
            time.sleep(min(poll_s, remaining))

    def _require_connected(self) -> None:
        if self._head is None:
            raise RuntimeError("VegaHeadCamera is not connected")


class VegaWristCameras:
    """Context-managed wrapper around the local dual-ISX031 API.

    On the competition Jetson the robot stack runs in Conda Python 3.13 while
    the vendor ``wrist_cameras`` binding is available only to system Python
    3.10 (through GObject).  If the in-process import fails, use the checked
    in helper under ``/usr/bin/python3`` and exchange fresh NumPy frames via a
    temporary directory.  This keeps robot/IK control in the tested Conda
    process and does not alter the camera labels or servo contract.
    """

    def __init__(self) -> None:
        self._manager = None
        self._cameras = None
        self._bridge = None

    def connect(self) -> None:
        if self._cameras is not None or self._bridge is not None:
            return
        try:
            from wrist_cameras import WristCameras
        except ImportError as exc:
            if os.environ.get("VEGA_WRIST_CAMERA_BRIDGE", "auto").lower() in ("0", "off", "false"):
                raise
            bridge = _WristCameraBridge()
            print(
                "WRIST CAMERA BRIDGE: using " + bridge.python,
                f"after in-process import failed: {exc}",
                flush=True,
            )
            bridge.connect()
            self._bridge = bridge
            return

        manager = WristCameras()
        cameras = manager.__enter__()
        self._manager = manager
        self._cameras = cameras

    def close(self) -> None:
        if self._manager is not None:
            self._manager.__exit__(None, None, None)
        if self._bridge is not None:
            self._bridge.close()
        self._manager = None
        self._cameras = None
        self._bridge = None

    def read(self, *, timeout: float = 3.0, fresh: bool = True) -> WristPair:
        if self._bridge is not None:
            return self._bridge.read(timeout=timeout, fresh=fresh)
        if self._cameras is None:
            raise RuntimeError("VegaWristCameras is not connected")
        obs = self._cameras.get_obs(timeout=timeout, fresh=fresh)
        return WristPair(
            wrist_a=_wrist_record(obs["wrist_a"]),
            wrist_b=_wrist_record(obs["wrist_b"]),
        )


class _WristCameraBridge:
    """Persistent system-Python wrist-camera process used on the Jetson."""

    def __init__(self) -> None:
        self.python = os.environ.get("VEGA_WRIST_CAMERA_PYTHON", "/usr/bin/python3")
        self.script = Path(__file__).resolve().parents[2] / "tools" / "vega_wrist_camera_bridge.py"
        self._process = None
        self._selector = None
        self._temporary = None
        self._request = 0

    def connect(self) -> None:
        if self._process is not None:
            return
        if not self.script.is_file():
            raise RuntimeError(f"wrist camera bridge script is missing: {self.script}")
        self._temporary = tempfile.TemporaryDirectory(prefix="vega_wrist_bridge_")
        environment = os.environ.copy()
        environment["VEGA_WRIST_BRIDGE_DIR"] = self._temporary.name
        # The vendor module is installed outside normal site-packages on the
        # Jetson.  Keep an explicit default for the child only; the parent
        # Conda process remains untouched.
        environment["PYTHONPATH"] = os.environ.get(
            "VEGA_WRIST_CAMERA_PYTHONPATH", "/opt/wrist-cameras"
        )
        self._process = subprocess.Popen(
            [self.python, str(self.script)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=environment,
        )
        self._selector = selectors.DefaultSelector()
        self._selector.register(self._process.stdout, selectors.EVENT_READ)
        try:
            ready = self._read_line(45.0)
            if not ready.get("ready"):
                raise RuntimeError(f"wrist camera bridge failed to start: {ready}")
        except Exception:
            self.close()
            raise

    def _read_line(self, timeout):
        if self._process is None or self._process.stdout is None or self._selector is None:
            raise RuntimeError("wrist camera bridge is not running")
        events = self._selector.select(timeout)
        if not events:
            code = self._process.poll()
            raise RuntimeError(f"wrist camera bridge timed out (returncode={code})")
        line = self._process.stdout.readline()
        if not line:
            error = ""
            if self._process.stderr is not None:
                error = self._process.stderr.read().strip()
            raise RuntimeError(f"wrist camera bridge exited: {error}")
        try:
            result = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"wrist camera bridge returned non-JSON output: {line!r}") from exc
        if not result.get("ok", result.get("ready", False)):
            raise RuntimeError(result.get("error", "wrist camera bridge request failed"))
        return result

    def read(self, *, timeout=3.0, fresh=True):
        if self._process is None or self._process.stdin is None:
            raise RuntimeError("wrist camera bridge is not connected")
        self._request += 1
        request = {
            "op": "read", "request": self._request,
            "timeout_s": float(timeout), "fresh": bool(fresh),
        }
        self._process.stdin.write(json.dumps(request) + "\n")
        self._process.stdin.flush()
        result = self._read_line(float(timeout) + 10.0)
        directory = Path(result["directory"])
        import numpy as np
        frames = {
            label: np.load(directory / f"{label}.npy", allow_pickle=False)
            for label in ("wrist_a", "wrist_b")
        }
        return WristPair(
            wrist_a=WristCameraFrame(
                rgb=frames["wrist_a"], frame_id=result["wrist_a"].get("frame_id"),
                timestamp_ns=result["wrist_a"].get("timestamp_ns"),
                received_monotonic_ns=result["wrist_a"].get("received_monotonic_ns"),
            ),
            wrist_b=WristCameraFrame(
                rgb=frames["wrist_b"], frame_id=result["wrist_b"].get("frame_id"),
                timestamp_ns=result["wrist_b"].get("timestamp_ns"),
                received_monotonic_ns=result["wrist_b"].get("received_monotonic_ns"),
            ),
        )

    def close(self):
        process, selector, temporary = self._process, self._selector, self._temporary
        self._process = self._selector = self._temporary = None
        if process is not None:
            try:
                if process.stdin is not None:
                    process.stdin.write(json.dumps({"op": "close"}) + "\n")
                    process.stdin.flush()
                process.wait(timeout=3.0)
            except (BrokenPipeError, OSError, subprocess.TimeoutExpired):
                process.terminate()
                try:
                    process.wait(timeout=2.0)
                except subprocess.TimeoutExpired:
                    process.kill()
        if selector is not None:
            selector.close()
        if temporary is not None:
            temporary.cleanup()


def _wrist_record(record: Mapping[str, Any]) -> WristCameraFrame:
    return WristCameraFrame(
        rgb=record["rgb"],
        frame_id=record.get("frame_id"),
        timestamp_ns=record.get("timestamp_ns"),
        received_monotonic_ns=record.get("received_monotonic_ns"),
    )


def intrinsics_from_camera_info(camera_info) -> tuple[float, float, float, float]:
    """Extract fx, fy, cx, cy from common camera-info representations.

    Runtime camera info is authoritative. This intentionally avoids embedding
    the example intrinsics from the field manual.
    """
    if camera_info is None:
        raise ValueError("camera_info is required")

    if isinstance(camera_info, Mapping):
        # Live DexSensor ZED info nests rectified intrinsics under
        # camera_info["intrinsics"]["left"].
        nested = camera_info.get("intrinsics")
        if isinstance(nested, Mapping):
            left = nested.get("left")
            if isinstance(left, Mapping) and all(
                key in left for key in ("fx", "fy", "cx", "cy")
            ):
                return tuple(float(left[key]) for key in ("fx", "fy", "cx", "cy"))

        # NumPy arrays have no scalar truth value. Camera-info commonly uses
        # one, so never select K with boolean `or`.
        k = camera_info.get("K")
        if k is None:
            k = camera_info.get("k")
        if k is not None:
            if len(k) != 9:
                raise ValueError("camera_info K must contain 9 values")
            return float(k[0]), float(k[4]), float(k[2]), float(k[5])

        for keyset in (
            ("fx", "fy", "cx", "cy"),
            ("f_x", "f_y", "c_x", "c_y"),
        ):
            if all(key in camera_info for key in keyset):
                return tuple(float(camera_info[key]) for key in keyset)

    k = getattr(camera_info, "K", None)
    if k is None:
        k = getattr(camera_info, "k", None)
    if k is not None:
        if len(k) != 9:
            raise ValueError("camera_info K must contain 9 values")
        return float(k[0]), float(k[4]), float(k[2]), float(k[5])

    attrs = ("fx", "fy", "cx", "cy")
    if all(hasattr(camera_info, key) for key in attrs):
        return tuple(float(getattr(camera_info, key)) for key in attrs)

    raise ValueError("Could not extract fx, fy, cx, cy from camera_info")


def depth_to_point_cloud(
    depth_m,
    camera_info,
    *,
    stride: int = 1,
    min_depth_m: float = 0.05,
    max_depth_m: float | None = None,
):
    """Reconstruct XYZ points in the rectified left-camera optical frame.

    Returns an (N, 3) float array. Invalid/non-finite depth and values outside
    the requested range are removed. This is geometry only; it does not apply
    T_base_camera or any board transform.
    """
    if stride < 1:
        raise ValueError("stride must be >= 1")

    import numpy as np

    depth = np.asarray(depth_m)
    if depth.ndim != 2:
        raise ValueError("depth_m must be a 2-D depth image")

    fx, fy, cx, cy = intrinsics_from_camera_info(camera_info)
    if not all(math.isfinite(value) for value in (fx, fy, cx, cy)) or fx <= 0 or fy <= 0:
        raise ValueError("Camera intrinsics must be finite with positive fx/fy")

    sampled = depth[::stride, ::stride].astype(np.float32, copy=False)
    vv, uu = np.indices(sampled.shape, dtype=np.float32)
    uu *= stride
    vv *= stride

    valid = np.isfinite(sampled) & (sampled >= float(min_depth_m))
    if max_depth_m is not None:
        valid &= sampled <= float(max_depth_m)

    z = sampled[valid]
    u = uu[valid]
    v = vv[valid]

    x = (u - cx) * z / fx
    y = (v - cy) * z / fy
    return np.column_stack((x, y, z))
